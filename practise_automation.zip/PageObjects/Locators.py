#HomePage
lnk_MyAccountPage =    "xpath://a[normalize-space()='My Account']"

#My account page
tbox_username   = "id:username"
tbox_password   = "id:password"
chbox_rememberme =    "id:rememberme"
btn_login     = "css:input[name='login']"
msg_errorMessage="xpath://ul[@class='woocommerce-error']/li"
lnk_logout  ="xpath://li[@class='woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--customer-logout']/a"
msg_welcome_info_text1="css:div[class='woocommerce-MyAccount-content']>p"
msg_welcome_info_text2="css:div[class='woocommerce-MyAccount-content']>p[2]"